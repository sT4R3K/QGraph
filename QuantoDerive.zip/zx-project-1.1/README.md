zx-project
==========

A basic project for QuantoDerive for working with the ZX-calculus

Provides the ZX-calculus axioms and a basic automated simplification procedure.

This is work in progress! Check out the repository every now and then
for updates, bug fixes, new features, etc.
